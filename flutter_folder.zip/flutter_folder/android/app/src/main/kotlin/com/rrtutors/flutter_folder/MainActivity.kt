package com.rrtutors.flutter_folder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
